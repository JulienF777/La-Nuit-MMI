@extends('layouts.com')
@section('css')
  <link href="/public/css/articles.css" rel="stylesheet">
@endsection
@section('content')
@endsection