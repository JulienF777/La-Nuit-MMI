@extends('layouts.appOn')

@section('content')
    <p>Et voici la page 2</p>
@endsection