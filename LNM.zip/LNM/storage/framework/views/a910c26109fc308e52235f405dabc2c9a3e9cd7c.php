
    <a href='index.php?action=page2'>Suivez ce lien</a>


<?php /**PATH C:\Users\hugo5\OneDrive\Bureau\Laravel\LNM\resources\views/index.blade.php ENDPATH**/ ?>