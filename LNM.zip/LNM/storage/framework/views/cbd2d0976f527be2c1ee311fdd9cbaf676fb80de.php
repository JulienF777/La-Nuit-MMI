

<?php echo e(dd($art)); ?>



<?php /**PATH C:\Users\hugo5\OneDrive\Bureau\Laravel\LNM\resources\views/aarticles.blade.php ENDPATH**/ ?>